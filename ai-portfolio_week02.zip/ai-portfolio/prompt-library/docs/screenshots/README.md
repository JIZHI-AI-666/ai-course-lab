# 截图存放处

按轮次命名，与 `prompt_iteration_log.md` 中的引用一一对应：

- `R0_翻车.png`　　最简陋指令的失控输出
- `R1_加角色格式.png`
- `R2_封闭错因清单.png`
- `R3_四维度配分.png`
- `R4_定版.png`
